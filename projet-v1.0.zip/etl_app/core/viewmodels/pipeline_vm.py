"""Pipeline ViewModel."""
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session

from etl_app.core.services.project_service import ProjectService
from etl_app.core.services.csv_service import CsvService
from etl_app.core.models.pipeline import StepType


class PipelineViewModel:
    def __init__(self, db: Session):
        self.project_svc = ProjectService(db)
        self.csv_svc = CsvService()

    def get_ingestion_data(self, project_id: int) -> Dict[str, Any]:
        config = self.project_svc.get_step_config(project_id, StepType.INGESTION)
        return {
            "project_id": project_id,
            "step_type": StepType.INGESTION.value,
            "config": config or {},
            "encodings": ["utf-8-sig", "utf-8", "latin-1", "cp1252", "iso-8859-1"],
            "delimiters": [
                {"value": ";", "label": "Point-virgule (;)"},
                {"value": ",", "label": "Virgule (,)"},
                {"value": "\t", "label": "Tabulation (\\t)"},
                {"value": "|", "label": "Pipe (|)"},
            ],
        }

    def get_staging_data(self, project_id: int) -> Dict[str, Any]:
        config = self.project_svc.get_step_config(project_id, StepType.STAGING)
        ingestion_cfg = self.project_svc.get_step_config(project_id, StepType.INGESTION)

        columns = []
        if ingestion_cfg and ingestion_cfg.get("file_path"):
            preview = self.csv_svc.get_preview(
                ingestion_cfg["file_path"],
                delimiter=ingestion_cfg.get("delimiter", ";"),
                encoding=ingestion_cfg.get("encoding", "utf-8-sig"),
                page_size=1,
            )
            columns = preview.get("columns", [])

        return {
            "project_id": project_id,
            "step_type": StepType.STAGING.value,
            "config": config or {},
            "available_columns": columns,
        }

    def get_ods_data(self, project_id: int) -> Dict[str, Any]:
        config = self.project_svc.get_step_config(project_id, StepType.ODS)
        staging_cfg = self.project_svc.get_step_config(project_id, StepType.STAGING)
        columns = staging_cfg.get("selected_columns", []) if staging_cfg else []
        staging_table_name = staging_cfg.get("table_name", "") if staging_cfg else ""

        # Pré-remplir source_staging_table si pas encore défini dans la config ODS
        ods_config = dict(config) if config else {}
        if not ods_config.get("source_staging_table") and staging_table_name:
            ods_config["source_staging_table"] = staging_table_name

        # Détecter les types/tailles des colonnes depuis le fichier CSV source
        column_type_hints: Dict[str, Any] = {}
        ingestion_cfg = self.project_svc.get_step_config(project_id, StepType.INGESTION)
        if ingestion_cfg and ingestion_cfg.get("file_path"):
            try:
                raw = self.csv_svc.detect_column_types(
                    ingestion_cfg["file_path"],
                    delimiter=ingestion_cfg.get("delimiter", ";"),
                    encoding=ingestion_cfg.get("encoding", "utf-8-sig"),
                )
                # Mapping type CSV → type SQL Server
                type_map = {
                    "INT": "INT",
                    "DECIMAL": "DECIMAL",
                    "DATE": "DATE",
                    "VARCHAR": "NVARCHAR",
                }
                for col, info in raw.items():
                    sql_type = type_map.get(info.get("detected_type", "VARCHAR"), "NVARCHAR")
                    column_type_hints[col] = {
                        "sql_type": sql_type,
                        "size": info.get("suggested_size", 500) if sql_type == "NVARCHAR" else None,
                    }
            except Exception:
                pass

        return {
            "project_id": project_id,
            "step_type": StepType.ODS.value,
            "config": ods_config,
            "source_columns": columns,
            "column_type_hints": column_type_hints,
            "sql_types": ["NVARCHAR", "INT", "BIGINT", "DECIMAL", "DATE",
                          "DATETIME2", "BIT", "FLOAT"],
        }

    def get_dimension_data(self, project_id: int) -> Dict[str, Any]:
        config = self.project_svc.get_step_config(project_id, StepType.DIMENSION)
        ods_cfg = self.project_svc.get_step_config(project_id, StepType.ODS)

        # Resolve ODS columns
        columns = ods_cfg.get("selected_columns", []) if ods_cfg else []
        if ods_cfg:
            mappings = ods_cfg.get("column_mappings", [])
            if mappings:
                columns = [m.get("target_column", m.get("source_column"))
                           for m in mappings]
            calc_cols = [c.get("name") for c in ods_cfg.get("calculated_columns", []) if c.get("name")]
            columns = columns + [c for c in calc_cols if c not in columns]

        # Resolve ODS default table name
        ods_table_name = ods_cfg.get("table_name", "") if ods_cfg else ""

        # Migrate legacy config (single dim → dimensions list)
        dim_config = dict(config) if config else {}
        if "table_name" in dim_config and "dimensions" not in dim_config:
            # Legacy single-dimension format — wrap it
            legacy = {k: dim_config[k] for k in [
                "table_name", "source_ods_table", "use_surrogate_key",
                "surrogate_key_column", "load_mode", "business_key_columns",
                "tracked_columns", "selected_columns",
            ] if k in dim_config}
            dim_config = {"dimensions": [legacy]}

        return {
            "project_id": project_id,
            "step_type": StepType.DIMENSION.value,
            "config": dim_config,
            "ods_columns": columns,
            "ods_table_name": ods_table_name,
        }

    def get_fact_data(self, project_id: int) -> Dict[str, Any]:
        config = self.project_svc.get_step_config(project_id, StepType.FACT)
        ods_cfg = self.project_svc.get_step_config(project_id, StepType.ODS)
        dim_cfg = self.project_svc.get_step_config(project_id, StepType.DIMENSION)

        columns = []
        if ods_cfg:
            mappings = ods_cfg.get("column_mappings", [])
            if mappings:
                columns = [m.get("target_column", m.get("source_column"))
                           for m in mappings]
            else:
                columns = ods_cfg.get("selected_columns", [])

        # ODS table name for auto-fill
        ods_table_name = ods_cfg.get("table_name", "") if ods_cfg else ""

        # Auto-fill source_ods_table if not yet set
        fact_config = dict(config) if config else {}
        if not fact_config.get("source_ods_table") and ods_table_name:
            fact_config["source_ods_table"] = ods_table_name

        # Collect dimension tables defined in the project
        project_dim_tables = []
        if dim_cfg:
            dims = dim_cfg.get("dimensions", [])
            if not dims and dim_cfg.get("table_name"):
                dims = [dim_cfg]
            project_dim_tables = [
                {"schema": d.get("dim_schema", "dim"), "table": d.get("table_name", "")}
                for d in dims if d.get("table_name")
            ]

        # Also collect dim tables already loaded in the local SQLite DB
        local_dim_tables: list = []
        try:
            project = self.project_svc.get_project(project_id)
            if project:
                from etl_app.core.services.local_db_service import LocalDbService
                local_db = LocalDbService(str(project.name))
                local_dim_tables = [
                    t for t in local_db.list_tables() if t.get("schema") == "dim"
                ]
        except Exception:
            pass

        return {
            "project_id": project_id,
            "step_type": StepType.FACT.value,
            "config": fact_config,
            "ods_columns": columns,
            "ods_table_name": ods_table_name,
            "project_dim_tables": project_dim_tables,
            "local_dim_tables": local_dim_tables,
        }

    def get_post_processing_data(self, project_id: int) -> Dict[str, Any]:
        config = self.project_svc.get_step_config(project_id, StepType.POST_PROCESSING)
        ingestion_cfg = self.project_svc.get_step_config(project_id, StepType.INGESTION)

        source_file = ""
        if ingestion_cfg:
            source_file = ingestion_cfg.get("file_path", "")

        return {
            "project_id": project_id,
            "step_type": StepType.POST_PROCESSING.value,
            "config": config or {},
            "source_file": source_file,
        }
