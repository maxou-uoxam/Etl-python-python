"""Documentation ViewModel."""
import mistune
from typing import Dict, Any
from sqlalchemy.orm import Session

from etl_app.core.services.project_service import ProjectService
from etl_app.core.services.yaml_service import YamlService
from etl_app.etl.generators import DocumentationGenerator, SqlGenerator

# Renderer Markdown → HTML avec les classes Tailwind
_md = mistune.create_markdown(
    plugins=["table"],
    renderer=mistune.HTMLRenderer(escape=False),
)


class DocumentationViewModel:
    def __init__(self, db: Session):
        self.project_svc = ProjectService(db)
        self.yaml_svc = YamlService()
        self.doc_gen = DocumentationGenerator()
        self.sql_gen = SqlGenerator()

    def generate_and_save(self, project_id: int) -> Dict[str, Any]:
        """Generate all documentation and SQL files, save to disk."""
        project = self.project_svc.get_project(project_id)
        if not project:
            return {"error": "Project not found"}

        project_config = self.project_svc._to_yaml_dict(project)

        # Documentation
        lineage_md = self.doc_gen.generate_data_lineage(project, project_config)

        self.yaml_svc.save_documentation(project.name, "data_lineage.md", lineage_md)

        # SQL scripts
        sql_files = self.sql_gen.generate_all(project_config)
        for path, content in sql_files.items():
            parts = path.split("/", 1)
            if len(parts) == 2:
                self.yaml_svc.save_sql(project.name, parts[1], content)

        return {
            "success": True,
            "project": project.name,
            "files_generated": len(sql_files) + 1,
            "lineage_preview": lineage_md,
            "lineage_html": _md(lineage_md),
        }
