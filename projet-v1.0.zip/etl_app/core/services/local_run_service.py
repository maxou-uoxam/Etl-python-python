"""Local pipeline runner — executes ETL steps into the project's SQLite local DB."""
import pandas as pd
from typing import Dict, Any, Optional
from loguru import logger

from etl_app.core.services.local_db_service import LocalDbService
from etl_app.core.services.csv_service import CsvService


class LocalRunService:
    """
    Runs individual ETL steps against the project's local SQLite DB.
    Does NOT require a SQL Server connection.
    """

    def __init__(self, project_name: str):
        self.project_name = project_name
        self.local_db = LocalDbService(project_name)
        self.csv_svc = CsvService()

    # ── Step runners ──────────────────────────────────────────────────────────

    def run_staging(self, ingestion_cfg: dict, staging_cfg: dict) -> Dict[str, Any]:
        """Read CSV and load into local SQLite staging table."""
        file_path = ingestion_cfg.get("file_path", "")
        if not file_path:
            return {"success": False, "message": "Chemin du fichier CSV non configuré."}

        delimiter = ingestion_cfg.get("delimiter", ";")
        encoding = ingestion_cfg.get("encoding", "utf-8-sig")
        has_header = ingestion_cfg.get("has_header", True)
        table_name = staging_cfg.get("table_name", "")
        if not table_name:
            return {"success": False, "message": "Nom de la table staging non configuré."}

        selected_columns = staging_cfg.get("selected_columns") or None
        batch_size = staging_cfg.get("batch_size", 1000)

        try:
            df = pd.read_csv(
                file_path,
                sep=delimiter,
                encoding=encoding,
                header=0 if has_header else None,
                dtype=str,
                keep_default_na=False,
                on_bad_lines="skip",
            )
            if selected_columns:
                df = df[[c for c in selected_columns if c in df.columns]]

            count = self.local_db.load_dataframe("sta", table_name, df, if_exists="replace")
            return {
                "success": True,
                "rows": count,
                "table": f"sta.{table_name}",
                "message": f"{count:,} lignes chargées dans sta.{table_name}",
            }
        except FileNotFoundError:
            return {"success": False, "message": f"Fichier introuvable : {file_path}"}
        except Exception as e:
            logger.error(f"[LocalRun] Staging failed: {e}")
            return {"success": False, "message": str(e)}

    def run_ods(self, staging_cfg: dict, ods_cfg: dict) -> Dict[str, Any]:
        """Transform staging data and load into local SQLite ODS table."""
        staging_table = staging_cfg.get("table_name", "")
        ods_table = ods_cfg.get("table_name", "")
        if not staging_table or not ods_table:
            return {"success": False, "message": "Table staging ou ODS non configurée."}

        if not self.local_db.table_exists("sta", staging_table):
            return {
                "success": False,
                "message": f"La table locale sta.{staging_table} n'existe pas. "
                           "Exécutez d'abord l'étape Staging localement.",
            }

        conn = self.local_db._conn()
        try:
            df = pd.read_sql(
                f'SELECT * FROM "sta__{staging_table}"', conn
            )
        finally:
            conn.close()

        try:
            # Apply column mappings
            mappings = ods_cfg.get("column_mappings", [])
            rename_map = {
                m["source_column"]: m["target_column"]
                for m in mappings
                if m.get("source_column") and m.get("target_column")
                and m["source_column"] in df.columns
            }
            if rename_map:
                df = df.rename(columns=rename_map)

            # Apply filters
            for f in ods_cfg.get("filters", []):
                expr = f.get("expression", "").strip()
                expr_type = f.get("expression_type", "python")
                if not expr:
                    continue
                try:
                    if expr_type == "python":
                        df = df.query(expr)
                    elif expr_type == "sql":
                        import pandasql as ps
                        df = ps.sqldf(f"SELECT * FROM df WHERE {expr}", {"df": df})
                except Exception as e:
                    logger.warning(f"[LocalRun] Filter skipped ({expr!r}): {e}")

            # Calculated columns (Python natif avec df en scope)
            for calc in ods_cfg.get("calculated_columns", []):
                name = calc.get("name", "").strip()
                expr = calc.get("expression", "").strip()
                expr_type = calc.get("expression_type", "python")
                if not name or not expr:
                    continue
                try:
                    if expr_type == "python":
                        df[name] = eval(expr, {"df": df, "pd": pd})
                    elif expr_type == "sql":
                        import pandasql as ps
                        result = ps.sqldf(f"SELECT {expr} AS {name} FROM df", {"df": df})
                        df[name] = result[name].values
                except Exception as e:
                    logger.warning(f"[LocalRun] Calc column '{name}' skipped ({expr!r}): {e}")

            # Select final columns — colonnes calculées remplacent les colonnes du même nom
            selected = ods_cfg.get("selected_columns") or list(df.columns)
            seen = set()
            deduped = []
            for c in reversed(selected):
                if c not in seen and c in df.columns:
                    seen.add(c)
                    deduped.insert(0, c)
            df = df[deduped]

            count = self.local_db.load_dataframe("ods", ods_table, df, if_exists="replace")
            return {
                "success": True,
                "rows": count,
                "table": f"ods.{ods_table}",
                "message": f"{count:,} lignes transformées dans ods.{ods_table}",
            }
        except Exception as e:
            logger.error(f"[LocalRun] ODS failed: {e}")
            return {"success": False, "message": str(e)}

    def run_dimension(self, ods_cfg: dict, dim_cfg: dict) -> Dict[str, Any]:
        """Load dimension table(s) from local ODS into local SQLite.

        dim_cfg can be either:
          - new format: {"dimensions": [{...}, {...}]}
          - legacy format: {"table_name": "...", ...}  (single dim)
        """
        # Normalise to list
        if "dimensions" in dim_cfg:
            dim_list = dim_cfg["dimensions"]
        elif dim_cfg.get("table_name"):
            dim_list = [dim_cfg]
        else:
            return {"success": False, "message": "Aucune dimension configurée."}

        if not dim_list:
            return {"success": False, "message": "La liste des dimensions est vide."}

        ods_table = ods_cfg.get("table_name", "")
        if not ods_table:
            return {"success": False, "message": "Table ODS non configurée."}

        if not self.local_db.table_exists("ods", ods_table):
            return {
                "success": False,
                "message": f"La table locale ods.{ods_table} n'existe pas. "
                           "Exécutez d'abord l'étape ODS localement.",
            }

        conn = self.local_db._conn()
        try:
            df_ods = pd.read_sql(f'SELECT * FROM "ods__{ods_table}"', conn)
        finally:
            conn.close()

        results = []
        total_rows = 0
        for single in dim_list:
            dim_table = single.get("table_name", "")
            if not dim_table:
                continue
            try:
                df = df_ods.copy()
                selected = single.get("selected_columns") or list(df.columns)
                df = df[[c for c in selected if c in df.columns]]

                # ── Exclure les lignes entièrement vides/nulles ──────────────
                # Une ligne est exclue si TOUTES les colonnes sélectionnées
                # sont NULL ou chaîne vide (équivalent SQL COALESCE(NULLIF…) IS NOT NULL)
                def _is_empty(val):
                    if val is None:
                        return True
                    s = str(val).strip()
                    return s == "" or s.lower() == "nan" or s.lower() == "none"

                all_empty_mask = df.apply(
                    lambda row: all(_is_empty(v) for v in row), axis=1
                )
                dropped_empty = all_empty_mask.sum()
                if dropped_empty:
                    logger.debug(
                        f"[LocalRun] dim.{dim_table}: {dropped_empty} ligne(s) "
                        "entièrement vide(s) exclues"
                    )
                df = df[~all_empty_mask]

                # ── DISTINCT sur les colonnes sélectionnées ──────────────────
                bk_cols = single.get("business_key_columns", [])
                if bk_cols:
                    # Filtrer les BK nulles/vides puis dédupliquer sur les BKs
                    for bk in bk_cols:
                        if bk in df.columns:
                            df = df[df[bk].notna() & (df[bk].astype(str).str.strip() != "")]
                    df = df.drop_duplicates(subset=[c for c in bk_cols if c in df.columns])
                else:
                    # Pas de BK définie : DISTINCT sur toutes les colonnes
                    df = df.drop_duplicates()

                # ── Surrogate key (après dedup) ──────────────────────────────
                if single.get("use_surrogate_key", True):
                    sk_col = single.get("surrogate_key_column", "sk_id")
                    df = df.reset_index(drop=True)
                    df.insert(0, sk_col, range(1, len(df) + 1))

                count = self.local_db.load_dataframe("dim", dim_table, df, if_exists="replace")
                total_rows += count
                results.append({"table": f"dim.{dim_table}", "rows": count, "success": True})
            except Exception as e:
                logger.error(f"[LocalRun] Dimension '{dim_table}' failed: {e}")
                results.append({"table": f"dim.{dim_table}", "error": str(e), "success": False})

        all_ok = all(r["success"] for r in results)
        names = ", ".join(r["table"] for r in results)
        return {
            "success": all_ok,
            "rows": total_rows,
            "tables": results,
            "message": f"{total_rows:,} lignes chargées ({names})",
        }

    def run_fact(self, ods_cfg: dict, fact_cfg: dict) -> Dict[str, Any]:
        """Load fact table from local ODS into local SQLite, with dimension joins."""
        ods_table  = ods_cfg.get("table_name", "")
        fact_table = fact_cfg.get("table_name", "")
        if not ods_table or not fact_table:
            return {"success": False, "message": "Table ODS ou faits non configurée."}

        if not self.local_db.table_exists("ods", ods_table):
            return {
                "success": False,
                "message": f"La table locale ods.{ods_table} n'existe pas. "
                           "Exécutez d'abord l'étape ODS localement.",
            }

        conn = self.local_db._conn()
        try:
            df = pd.read_sql(f'SELECT * FROM "ods__{ods_table}"', conn)
        finally:
            conn.close()

        try:
            # ── Jointures avec les dimensions ─────────────────────────────────
            joins = fact_cfg.get("joins", [])
            for j in joins:
                dim_schema = j.get("dimension_schema", "dim")
                dim_table  = j.get("dimension_table", "")
                sk_col     = j.get("surrogate_key_column", "sk_id")
                join_keys  = j.get("join_keys", [])
                alias      = j.get("alias") or f"dim_{dim_table}"

                if not dim_table or not join_keys:
                    continue

                if not self.local_db.table_exists(dim_schema, dim_table):
                    logger.warning(
                        f"[LocalRun] Dimension '{dim_schema}.{dim_table}' introuvable "
                        "en local — jointure ignorée."
                    )
                    continue

                conn = self.local_db._conn()
                try:
                    df_dim = pd.read_sql(
                        f'SELECT * FROM "{dim_schema}__{dim_table}"', conn
                    )
                finally:
                    conn.close()

                # Clés de jointure côté dimension
                dim_key_cols = [k["dimension"] for k in join_keys if k.get("dimension")]

                # ── Forcer les clés de jointure en string des deux côtés ──────
                # (les données ODS viennent de CSV = tout en str ; la dim peut
                #  avoir des int/float selon pandas → on normalise)
                left_keys  = [k["source"]    for k in join_keys if k.get("source") and k.get("dimension")]
                right_keys = [k["dimension"] for k in join_keys if k.get("source") and k.get("dimension")]

                for lk in left_keys:
                    if lk in df.columns:
                        df[lk] = df[lk].astype(str).str.strip()
                for rk in right_keys:
                    if rk in df_dim.columns:
                        df_dim[rk] = df_dim[rk].astype(str).str.strip()

                # ── Renommer les colonnes dim avec préfixe alias ──────────────
                # • Les clés de jointure côté dim : on les garde telles quelles
                #   pour que pandas puisse faire le merge, on les drop après
                # • La SK est renommée en alias_sk_col
                # • Les autres colonnes sont renommées alias_col
                rename_map = {}
                for col in df_dim.columns:
                    if col == sk_col:
                        rename_map[col] = f"{alias}_{sk_col}"
                    elif col not in dim_key_cols:
                        rename_map[col] = f"{alias}_{col}"
                    # les dim_key_cols ne sont pas renommées → utilisées pour le merge
                df_dim = df_dim.rename(columns=rename_map)

                # right_keys restent inchangées (pas dans rename_map)
                # Vérifier que les colonnes existent
                missing_left  = [c for c in left_keys  if c not in df.columns]
                missing_right = [c for c in right_keys if c not in df_dim.columns]
                if missing_left or missing_right:
                    logger.warning(
                        f"[LocalRun] Jointure {alias} ignorée — colonnes manquantes : "
                        f"ODS={missing_left}, dim={missing_right}"
                    )
                    continue

                df = df.merge(
                    df_dim,
                    left_on=left_keys,
                    right_on=right_keys,
                    how="left",
                    suffixes=("", f"_{alias}_dup"),  # évite _x/_y sur les noms ODS
                )

                # ── Supprimer les colonnes dupliquées issues du merge ──────────
                # (les right_keys dupliquent des colonnes déjà présentes dans ODS)
                dup_cols = [f"{rk}_{alias}_dup" for rk in right_keys]
                df = df.drop(columns=[c for c in dup_cols if c in df.columns])

                # Si les clés de jointure ODS et dim ont le même nom, pandas
                # les garde séparément — on supprime la copie dim
                if right_keys != left_keys:
                    df = df.drop(columns=[c for c in right_keys if c in df.columns and c not in left_keys])

                # ── Convertir la SK de float → int (LEFT JOIN peut produire NaN) ─
                sk_result_col = f"{alias}_{sk_col}"
                if sk_result_col in df.columns:
                    df[sk_result_col] = (
                        pd.to_numeric(df[sk_result_col], errors="coerce")
                        .astype("Int64")   # Int64 nullable supporte les NaN
                    )

            # ── Sélection des colonnes finales ────────────────────────────────
            selected = fact_cfg.get("selected_columns") or list(df.columns)
            df = df[[c for c in selected if c in df.columns]]

            count = self.local_db.load_dataframe("fact", fact_table, df, if_exists="replace")
            return {
                "success": True,
                "rows": count,
                "table": f"fact.{fact_table}",
                "message": f"{count:,} lignes chargées dans fact.{fact_table}",
            }
        except Exception as e:
            logger.error(f"[LocalRun] Fact failed: {e}")
            return {"success": False, "message": str(e)}
