"""Local SQLite database service — mirrors SQL Server schemas for local testing."""
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional
import pandas as pd
from loguru import logger

from etl_app.config import settings


# SQL Server → SQLite type mapping
_SQLSERVER_TO_SQLITE = {
    "NVARCHAR": "TEXT",
    "VARCHAR": "TEXT",
    "CHAR": "TEXT",
    "TEXT": "TEXT",
    "INT": "INTEGER",
    "BIGINT": "INTEGER",
    "SMALLINT": "INTEGER",
    "TINYINT": "INTEGER",
    "BIT": "INTEGER",
    "DECIMAL": "REAL",
    "NUMERIC": "REAL",
    "FLOAT": "REAL",
    "REAL": "REAL",
    "DATE": "TEXT",
    "DATETIME": "TEXT",
    "DATETIME2": "TEXT",
}

# Schema names used as table prefixes in SQLite
SCHEMAS = ["sta", "ods", "dim", "fact"]


def _db_path(project_name: str) -> Path:
    path = settings.projects_dir / project_name / "local.db"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def get_local_connection(project_name: str) -> sqlite3.Connection:
    """Return an open SQLite connection for the project's local DB."""
    conn = sqlite3.connect(str(_db_path(project_name)))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


class LocalDbService:
    """Manages the per-project SQLite local database."""

    def __init__(self, project_name: str):
        self.project_name = project_name
        self.db_path = _db_path(project_name)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _conn(self) -> sqlite3.Connection:
        return get_local_connection(self.project_name)

    def _sqlite_type(self, sql_server_type: str) -> str:
        key = sql_server_type.upper().split("(")[0].strip()
        return _SQLSERVER_TO_SQLITE.get(key, "TEXT")

    def _table_key(self, schema: str, table: str) -> str:
        """SQLite table name: schema__table."""
        return f"{schema}__{table}"

    # ── Table operations ──────────────────────────────────────────────────────

    def create_or_replace_table(
        self,
        schema: str,
        table: str,
        columns: List[Dict[str, Any]],
    ) -> None:
        """
        Create (or replace) a SQLite table.

        columns: list of {"name": str, "sql_type": str, "nullable": bool}
        """
        key = self._table_key(schema, table)
        col_defs = ", ".join(
            f'"{c["name"]}" {self._sqlite_type(c.get("sql_type", "NVARCHAR"))}'
            + (" NULL" if c.get("nullable", True) else " NOT NULL")
            for c in columns
        )
        conn = self._conn()
        try:
            conn.execute(f'DROP TABLE IF EXISTS "{key}"')
            conn.execute(f'CREATE TABLE "{key}" ({col_defs})')
            conn.commit()
            logger.info(f"[LocalDB] Created table '{key}' in {self.db_path.name}")
        finally:
            conn.close()

    def load_dataframe(
        self,
        schema: str,
        table: str,
        df: pd.DataFrame,
        if_exists: str = "replace",
    ) -> int:
        """Load a DataFrame into a local SQLite table. Returns row count."""
        key = self._table_key(schema, table)
        conn = self._conn()
        try:
            df.to_sql(key, conn, if_exists=if_exists, index=False)
            conn.commit()
            count = conn.execute(f'SELECT COUNT(*) FROM "{key}"').fetchone()[0]
            logger.info(f"[LocalDB] Loaded {count:,} rows into '{key}'")
            return count
        finally:
            conn.close()

    def table_exists(self, schema: str, table: str) -> bool:
        key = self._table_key(schema, table)
        conn = self._conn()
        try:
            row = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (key,)
            ).fetchone()
            return row is not None
        finally:
            conn.close()

    # ── Preview ───────────────────────────────────────────────────────────────

    def preview_table(
        self,
        schema: str,
        table: str,
        page: int = 1,
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """Return paginated rows from a local SQLite table."""
        key = self._table_key(schema, table)
        conn = self._conn()
        try:
            if not self.table_exists(schema, table):
                return {
                    "error": f"Table '{schema}.{table}' not found in local DB. "
                             "Run the step locally first.",
                    "columns": [], "rows": [], "total_rows": 0,
                }
            total = conn.execute(f'SELECT COUNT(*) FROM "{key}"').fetchone()[0]
            offset = (page - 1) * page_size
            cursor = conn.execute(
                f'SELECT * FROM "{key}" LIMIT ? OFFSET ?', (page_size, offset)
            )
            cols = [d[0] for d in cursor.description]
            rows = [list(r) for r in cursor.fetchall()]
            return {
                "schema": schema,
                "table": table,
                "columns": cols,
                "rows": rows,
                "total_rows": total,
                "page": page,
                "page_size": page_size,
                "total_pages": max(1, (total + page_size - 1) // page_size),
            }
        finally:
            conn.close()

    def list_tables(self) -> List[Dict[str, Any]]:
        """List all tables in the local DB with their row counts."""
        conn = self._conn()
        try:
            rows = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            ).fetchall()
            result = []
            for (name,) in rows:
                count = conn.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0]
                # Parse schema__table back to schema / table
                if "__" in name:
                    schema, tbl = name.split("__", 1)
                else:
                    schema, tbl = "", name
                result.append({
                    "key": name,
                    "schema": schema,
                    "table": tbl,
                    "row_count": count,
                })
            return result
        finally:
            conn.close()

    def drop_table(self, schema: str, table: str) -> None:
        key = self._table_key(schema, table)
        conn = self._conn()
        try:
            conn.execute(f'DROP TABLE IF EXISTS "{key}"')
            conn.commit()
        finally:
            conn.close()

    def db_size_kb(self) -> float:
        if self.db_path.exists():
            return round(self.db_path.stat().st_size / 1024, 1)
        return 0.0
