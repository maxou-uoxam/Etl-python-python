"""Automatic documentation generator."""
import json
from datetime import datetime
from typing import Dict, Any, List
from etl_app.core.models.pipeline import StepType


def _cell(value: str) -> str:
    """Échappe les pipes et sauts de ligne dans une cellule de tableau Markdown."""
    return str(value).replace("|", "\\|").replace("\n", " ").replace("\r", "")


class DocumentationGenerator:
    def generate_data_lineage(self, project: Any,
                               project_config: Dict[str, Any]) -> str:
        """Generate data lineage markdown document."""
        steps = project_config.get("pipeline", {}).get("steps", {})
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

        lines = [
            f"# Data Lineage — {project.name}",
            f"",
            f"> Generated: {now}",
            f"",
            f"## Overview",
            f"",
            f"```",
            f"Source CSV → [{steps.get('staging',{}).get('config',{}).get('table_name','sta.*')}] → "
            f"[{steps.get('ods',{}).get('config',{}).get('table_name','ods.*')}] → DWH",
            f"```",
            f"",
        ]

        # Source
        ingestion = steps.get(StepType.INGESTION.value, {}).get("config", {})
        # Le délimiteur peut être "|" — on l'échappe pour ne pas casser le tableau Markdown
        delimiter_display = ingestion.get('delimiter', ';').replace("|", "\\|")
        lines += [
            "## 1. Source",
            "",
            "| Attribut | Valeur |",
            "|----------|--------|",
            f"| Fichier | `{_cell(ingestion.get('file_path', 'N/A'))}` |",
            f"| Délimiteur | `{delimiter_display}` |",
            f"| Encodage | `{_cell(ingestion.get('encoding', 'utf-8-sig'))}` |",
            f"| En-tête | `{_cell(ingestion.get('has_header', True))}` |",
            "",
        ]

        # Staging
        staging = steps.get(StepType.STAGING.value, {}).get("config", {})
        if staging.get("table_name"):
            cols = staging.get("selected_columns", [])
            lines += [
                "## 2. Staging",
                "",
                f"**Table** : `sta.{staging['table_name']}`",
                "",
                "| Colonne | Type | Taille |",
                "|---------|------|--------|",
            ]
            for col in cols:
                lines.append(f"| {_cell(col)} | VARCHAR | 4000 |")
            lines.append("")

        # ODS
        ods = steps.get(StepType.ODS.value, {}).get("config", {})
        if ods.get("table_name"):
            mappings = ods.get("column_mappings", [])
            calcs = ods.get("calculated_columns", [])
            lines += [
                "## 3. ODS",
                "",
                f"**Table** : `ods.{ods['table_name']}`",
                "",
                "| Colonne | Type | Taille | Source | Transformation | Renommage |",
                "|---------|------|--------|--------|----------------|-----------|",
            ]
            for m in mappings:
                src = m.get("source_column", "")
                tgt = m.get("target_column", src)
                t = m.get("target_type", "NVARCHAR")
                sz = m.get("target_size", 500)
                renamed = f"{src} → {tgt}" if src != tgt else "-"
                transform = _cell(m.get("transformation") or "-")
                lines.append(f"| {_cell(tgt)} | {t} | {sz} | {_cell(src)} | {transform} | {renamed} |")
            for calc in calcs:
                expr = _cell(calc.get("expression", "")[:60])
                lines.append(f"| {_cell(calc['name'])} | calculé | - | - | `{expr}` | - |")
            lines.append("")

        # Dimension
        dim = steps.get(StepType.DIMENSION.value, {}).get("config", {})
        if dim.get("table_name"):
            lines += [
                "## 4. Dimension",
                "",
                f"**Table** : `dim.{dim['table_name']}`  ",
                f"**Mode** : {dim.get('load_mode', 'insert')}  ",
                f"**Clé métier** : {', '.join(dim.get('business_key_columns', []))}  ",
                f"**Colonnes surveillées** : {', '.join(dim.get('tracked_columns', []))}",
                "",
                "| Colonne | Type | Taille | Origine | Rôle |",
                "|---------|------|--------|---------|------|",
            ]
            sk = dim.get("surrogate_key_column", "sk_id")
            if dim.get("use_surrogate_key"):
                lines.append(f"| {sk} | INT IDENTITY | - | Généré | Surrogate Key |")
            for col in dim.get("selected_columns", []):
                role = "Business Key" if col in dim.get("business_key_columns", []) else \
                       "Surveillée" if col in dim.get("tracked_columns", []) else "Attribut"
                lines.append(f"| {_cell(col)} | NVARCHAR | 500 | ODS | {role} |")
            lines.append("")

        # Fact
        fact = steps.get(StepType.FACT.value, {}).get("config", {})
        if fact.get("table_name"):
            joins = fact.get("joins", [])
            ods_table = fact.get("source_ods_table", "")
            selected_cols = fact.get("selected_columns", [])

            # Déduire les colonnes SK depuis les jointures
            sk_cols: dict[str, str] = {}  # nom_col → origine
            for j in joins:
                alias = j.get("alias") or f"dim_{j.get('dimension_table','')}"
                sk = j.get("surrogate_key_column", "sk_id")
                sk_col_name = f"{alias}_{sk}"
                sk_cols[sk_col_name] = f"{j.get('dimension_schema','dim')}.{j.get('dimension_table','')}"

            lines += [
                "## 5. Table de Faits",
                "",
                f"**Table** : `fact.{fact['table_name']}`  ",
                f"**Source ODS** : `ods.{ods_table}`  ",
                f"**Jointures** : {len(joins)}",
                "",
            ]

            # Tableau des jointures
            if joins:
                lines += [
                    "### Jointures",
                    "",
                    "| Dimension | Clé ODS (source) | Clé Dimension | Surrogate Key résultante |",
                    "|-----------|-----------------|---------------|--------------------------|",
                ]
                for j in joins:
                    alias = j.get("alias") or f"dim_{j.get('dimension_table','')}"
                    sk = j.get("surrogate_key_column", "sk_id")
                    dim_ref = f"{j.get('dimension_schema','dim')}.{j.get('dimension_table','')}"
                    sk_result = f"{alias}_{sk}"
                    for k in j.get("join_keys", []):
                        lines.append(
                            f"| {_cell(dim_ref)} "
                            f"| {_cell(k.get('source', ''))} "
                            f"| {_cell(k.get('dimension', ''))} "
                            f"| `{_cell(sk_result)}` |"
                        )
                lines.append("")

            # Tableau des colonnes
            if selected_cols or sk_cols:
                lines += [
                    "### Colonnes",
                    "",
                    "| Colonne | Type | Taille | Origine |",
                    "|---------|------|--------|---------|",
                ]
                for col in selected_cols:
                    if col in sk_cols:
                        lines.append(f"| {_cell(col)} | INT | - | {_cell(sk_cols[col])} (SK) |")
                    else:
                        lines.append(f"| {_cell(col)} | NVARCHAR | 500 | `ods.{_cell(ods_table)}` |")
                # SK non encore dans selected_cols
                for sk_col, origin in sk_cols.items():
                    if sk_col not in selected_cols:
                        lines.append(f"| {_cell(sk_col)} | INT | - | {_cell(origin)} (SK) |")
                lines.append("")

        return "\n".join(lines)

    def generate_metrics(self, project: Any,
                          project_config: Dict[str, Any]) -> str:
        """Generate metrics JSON."""
        steps = project_config.get("pipeline", {}).get("steps", {})
        staging_cfg = steps.get(StepType.STAGING.value, {}).get("config", {})
        ods_cfg = steps.get(StepType.ODS.value, {}).get("config", {})
        dim_cfg = steps.get(StepType.DIMENSION.value, {}).get("config", {})
        fact_cfg = steps.get(StepType.FACT.value, {}).get("config", {})

        metrics = {
            "project": project.name,
            "generated_at": datetime.utcnow().isoformat(),
            "staging": {
                "table_count": 1 if staging_cfg.get("table_name") else 0,
                "tables": [staging_cfg["table_name"]] if staging_cfg.get("table_name") else [],
            },
            "ods": {
                "table_count": 1 if ods_cfg.get("table_name") else 0,
                "tables": [ods_cfg["table_name"]] if ods_cfg.get("table_name") else [],
            },
            "datawarehouse": {
                "dimensions": {
                    "table_count": 1 if dim_cfg.get("table_name") else 0,
                    "tables": [f"dim.{dim_cfg['table_name']}"] if dim_cfg.get("table_name") else [],
                },
                "facts": {
                    "table_count": 1 if fact_cfg.get("table_name") else 0,
                    "tables": [f"fact.{fact_cfg['table_name']}"] if fact_cfg.get("table_name") else [],
                },
            },
        }
        return json.dumps(metrics, indent=2, ensure_ascii=False)
