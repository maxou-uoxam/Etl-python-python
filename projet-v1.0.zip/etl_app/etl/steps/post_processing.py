"""Step 6 - Post processing (file move/copy on success)."""
import shutil
from datetime import datetime
from pathlib import Path
from loguru import logger
from .base import BaseStep, StepResult


class PostProcessingStep(BaseStep):
    def execute(self, config: dict, context: dict) -> StepResult:
        source_file = context.get("source_file")
        all_success = context.get("all_previous_success", True)

        action      = config.get("action", "move")
        output_path = config.get("output_path", "")
        rename_ts   = config.get("rename_with_timestamp", False)

        if not source_file:
            return StepResult(True, message="No file to process (no source file in context).")

        if not all_success:
            logger.warning("Previous steps had failures — skipping post-processing.")
            return StepResult(True, message="Skipped post-processing due to previous errors.")

        if action == "none" or not output_path:
            return StepResult(True, message="No action configured — file stays in place.")

        try:
            src     = Path(source_file)
            out_dir = Path(output_path)

            # Calcul du nom de destination
            fname = src.name
            if rename_ts:
                ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
                dot = fname.rfind(".")
                fname = (fname[:dot] + "_" + ts + fname[dot:]) if dot > 0 else (fname + "_" + ts)

            if self.is_dry_run:
                return StepResult(
                    True,
                    message=f"[DRY RUN] Would {action} {src.name} → {out_dir / fname}",
                )

            out_dir.mkdir(parents=True, exist_ok=True)
            dest = out_dir / fname

            if action == "copy":
                shutil.copy2(str(src), str(dest))
                logger.info(f"Copied {src.name} → {dest}")
                return StepResult(True, message=f"File copied to {dest}")
            else:  # move
                shutil.move(str(src), str(dest))
                logger.info(f"Moved {src.name} → {dest}")
                return StepResult(True, message=f"File moved to {dest}")

        except Exception as e:
            logger.error(f"Post-processing failed: {e}")
            return StepResult(False, message=str(e))
