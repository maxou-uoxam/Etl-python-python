"""API routes for local SQLite environment (testing & preview)."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from etl_app.database import get_db
from etl_app.core.services.project_service import ProjectService
from etl_app.core.services.local_db_service import LocalDbService
from etl_app.core.services.local_run_service import LocalRunService
from etl_app.core.models.pipeline import StepType

router = APIRouter(prefix="/api/local", tags=["Local DB"])


def _get_project_and_services(project_id: int, db: Session):
    svc = ProjectService(db)
    project = svc.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    local_db = LocalDbService(project.name)
    local_run = LocalRunService(project.name)
    return project, svc, local_db, local_run


# ── Info ──────────────────────────────────────────────────────────────────────

@router.get("/{project_id}/info")
def local_db_info(project_id: int, db: Session = Depends(get_db)):
    """Return info about the project's local SQLite DB."""
    project, svc, local_db, _ = _get_project_and_services(project_id, db)
    return {
        "project_id": project_id,
        "project_name": project.name,
        "db_path": str(local_db.db_path),
        "db_size_kb": local_db.db_size_kb(),
        "tables": local_db.list_tables(),
    }


# ── Run steps locally ─────────────────────────────────────────────────────────

@router.post("/{project_id}/run/staging")
def run_staging_local(project_id: int, db: Session = Depends(get_db)):
    """Execute staging step locally into SQLite."""
    project, svc, _, local_run = _get_project_and_services(project_id, db)
    ingestion_cfg = svc.get_step_config(project_id, StepType.INGESTION) or {}
    staging_cfg = svc.get_step_config(project_id, StepType.STAGING) or {}
    result = local_run.run_staging(ingestion_cfg, staging_cfg)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/{project_id}/run/ods")
def run_ods_local(project_id: int, db: Session = Depends(get_db)):
    """Execute ODS step locally into SQLite."""
    project, svc, _, local_run = _get_project_and_services(project_id, db)
    staging_cfg = svc.get_step_config(project_id, StepType.STAGING) or {}
    ods_cfg = svc.get_step_config(project_id, StepType.ODS) or {}
    result = local_run.run_ods(staging_cfg, ods_cfg)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/{project_id}/run/dimension")
def run_dimension_local(project_id: int, db: Session = Depends(get_db)):
    """Execute all dimension steps locally into SQLite."""
    project, svc, _, local_run = _get_project_and_services(project_id, db)
    ods_cfg = svc.get_step_config(project_id, StepType.ODS) or {}
    dim_cfg = svc.get_step_config(project_id, StepType.DIMENSION) or {}
    result = local_run.run_dimension(ods_cfg, dim_cfg)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/{project_id}/run/dimension/{dim_table}")
def run_single_dimension_local(
    project_id: int,
    dim_table: str,
    db: Session = Depends(get_db),
):
    """Execute a single dimension step locally into SQLite (by table name)."""
    project, svc, _, local_run = _get_project_and_services(project_id, db)
    ods_cfg = svc.get_step_config(project_id, StepType.ODS) or {}
    dim_cfg = svc.get_step_config(project_id, StepType.DIMENSION) or {}

    # Extract the matching dimension config from the list
    dimensions = dim_cfg.get("dimensions", [])
    if not dimensions and dim_cfg.get("table_name"):
        dimensions = [dim_cfg]

    single = next((d for d in dimensions if d.get("table_name") == dim_table), None)
    if not single:
        raise HTTPException(
            status_code=404,
            detail=f"Dimension '{dim_table}' introuvable dans la configuration du projet.",
        )

    result = local_run.run_dimension(ods_cfg, {"dimensions": [single]})
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/{project_id}/run/fact")
def run_fact_local(project_id: int, db: Session = Depends(get_db)):
    """Execute fact step locally into SQLite."""
    project, svc, _, local_run = _get_project_and_services(project_id, db)
    ods_cfg = svc.get_step_config(project_id, StepType.ODS) or {}
    fact_cfg = svc.get_step_config(project_id, StepType.FACT) or {}
    result = local_run.run_fact(ods_cfg, fact_cfg)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return result


# ── Drop table ────────────────────────────────────────────────────────────────

@router.delete("/{project_id}/drop/{schema}/{table}")
def drop_local_table(
    project_id: int,
    schema: str,
    table: str,
    db: Session = Depends(get_db),
):
    """Drop (truncate) a local SQLite table."""
    project, _, local_db, _ = _get_project_and_services(project_id, db)
    if not local_db.table_exists(schema, table):
        raise HTTPException(
            status_code=404,
            detail=f"Table '{schema}.{table}' introuvable dans la base locale."
        )
    local_db.drop_table(schema, table)
    return {"success": True, "message": f"Table {schema}.{table} supprimée."}


# ── Preview ───────────────────────────────────────────────────────────────────

@router.get("/{project_id}/preview/{schema}/{table}")
def preview_local_table(
    project_id: int,
    schema: str,
    table: str,
    page: int = 1,
    page_size: int = 50,
    db: Session = Depends(get_db),
):
    """Preview a local SQLite table with pagination."""
    project, _, local_db, _ = _get_project_and_services(project_id, db)
    result = local_db.preview_table(schema, table, page=page, page_size=page_size)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result
